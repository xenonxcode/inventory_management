<footer>
    <p>&copy; 2024 Dinas Pertanian</p>
</footer>
