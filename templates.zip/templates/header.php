<header>
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="insert.php">Tambah Data</a></li>
            <li><a href="export.php">Ekspor ke Excel</a></li>
        </ul>
    </nav>
</header>
